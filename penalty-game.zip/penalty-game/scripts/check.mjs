// Syntax check for every JS module (used locally and in CI)
import { readdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
for (const f of readdirSync('public/js')) {
  if (f.endsWith('.js')) execFileSync(process.execPath, ['--check', `public/js/${f}`], { stdio: 'inherit' });
}
console.log('OK: all modules passed syntax check');
