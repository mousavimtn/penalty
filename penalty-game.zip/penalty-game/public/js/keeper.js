// Goalkeeper "puppet": the photo is cut into 6 parts that rotate around joints.
import { lerp, cl, eo } from './utils.js';

const NAMES = ['legL', 'legR', 'armL', 'armR', 'torso', 'head'];
// joint positions in the original photo (pixels)
const PV = { armL: [162, 150], armR: [295, 150], legL: [195, 385], legR: [260, 385], torso: [227, 330], head: [228, 112] };
const HIP = [227, 330], REF_H = 592;

export class Keeper {
  constructor() { this.img = {}; this.meta = null; this.ready = false; this.t = 0; this.x = 0; this.y = 0; this.a = 0; this.e = 0; this.c = 0; this.trail = 0; }

  async load(base) {
    this.meta = await (await fetch(base + 'meta.json')).json();
    await Promise.all(NAMES.map((n) => new Promise((res, rej) => {
      const i = new Image(); i.onload = res; i.onerror = rej; i.src = base + n + '.webp'; this.img[n] = i;
    })));
    this.ready = true;
  }

  idlePos(L) { return [L.sx, L.gb - 0.55 * L.kh]; }

  update(dt, L, shot) {
    this.t += dt;
    const [ix, iy] = this.idlePos(L);
    if (!shot) { this.x = ix + Math.sin(this.t * 2) * L.gw * 0.012; this.y = iy; this.a = 0; this.e = 0; this.c = 0; return; }
    const kh = L.kh, k = shot.clock;
    this.trail = shot.ka > 0 ? 1 : 0;
    this.c = k < 0.12 ? k / 0.12 : Math.max(0, 1 - (k - 0.12) / 0.15);          // crouch before the jump
    const ke = eo(cl((k - 0.12) / 0.48, 0, 1));                                     // dive progress
    this.e = ke;
    this.x = lerp(ix, shot.kx, ke);
    this.y = lerp(iy, shot.ky, ke) - Math.sin(Math.PI * ke) * kh * 0.12 + this.c * kh * 0.05;
    this.a = shot.ka * ke;
    const fall = eo(cl((k - 0.78) / 0.35, 0, 1));                                   // gravity after the dive
    const gy = L.gb - kh * lerp(0.55, 0.14, cl(Math.abs(shot.ka) / 1.2, 0, 1));
    if (this.y < gy) this.y = lerp(this.y, gy, fall);
    if (shot.phase === 'after' && shot.wait > 1.15) {                              // get back up
      const u = eo(cl((shot.wait - 1.15) / 0.5, 0, 1));
      this.x = lerp(this.x, ix, u); this.y = lerp(this.y, iy, u); this.a *= 1 - u; this.e *= 1 - u;
    }
  }

  _part(ctx, n, k, ang, dy) {
    const m = this.meta[n], pv = PV[n];
    ctx.save();
    ctx.translate((pv[0] - HIP[0]) * k, (pv[1] - HIP[1]) * k + (dy || 0));
    ctx.rotate(ang || 0);
    ctx.drawImage(this.img[n], (m.ox - pv[0]) * k, (m.oy - pv[1]) * k, m.w * k, m.h * k);
    ctx.restore();
  }

  draw(ctx, L) {
    if (!this.ready) return;
    const kh = L.kh, k = (kh * 1.15) / REF_H, e = this.e, c = this.c, t = this.t;
    ctx.save(); ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.beginPath();
    ctx.ellipse(this.x, L.gb + 2, kh * 0.2 * (1 + 0.5 * e), kh * 0.03, 0, 0, 7); ctx.fill(); ctx.restore();

    const ea = Math.min(1, e * 1.5), armBase = 0.5 + 0.3 * c;
    const aL = lerp(armBase + 0.06 * Math.sin(t * 5), Math.PI + 0.12, ea);
    const aR = -lerp(armBase + 0.06 * Math.sin(t * 5 + 1.6), Math.PI + 0.12, ea);
    const spread = 0.08 + 0.03 * Math.sin(t * 5) + 0.17 * c, tr = this.trail;
    const lL = lerp(spread, 0.35 + 0.3 * tr, e), lR = -lerp(spread, 0.35 + 0.3 * (1 - tr), e);
    const bob = -Math.abs(Math.sin(t * 4)) * kh * 0.01 * (1 - e);
    const lean = Math.sin(t * 2.5) * 0.025 * (1 - e);

    ctx.save(); ctx.translate(this.x, this.y); ctx.rotate(this.a); ctx.scale(1 + 0.03 * e, 1 - 0.04 * c + 0.05 * e);
    this._part(ctx, 'legL', k, lL); this._part(ctx, 'legR', k, lR);
    ctx.save(); ctx.rotate(lean);
    this._part(ctx, 'armL', k, aL, bob); this._part(ctx, 'armR', k, aR, bob);
    this._part(ctx, 'torso', k, 0, bob); this._part(ctx, 'head', k, Math.sin(t * 3) * 0.03, bob);
    ctx.restore(); ctx.restore();
  }
}
