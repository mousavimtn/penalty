import { CONFIG as C } from './config.js';
import { lerp, cl, eo } from './utils.js';
import * as audio from './audio.js';
import { computeLayout, buildBackground, drawGoalBack, drawGoalFront, drawBall } from './scene.js';
import { Keeper } from './keeper.js';

const cv = document.getElementById('game'), ctx = cv.getContext('2d'), bg = document.createElement('canvas');
const $ = (id) => document.getElementById(id);
const keeper = new Keeper();
let W, H, dpr, L;
const S = { shots: 0, goals: 0, results: [], mode: 'aim', shot: null, hover: null, shake: 0, parts: [], popup: null, spin: 0, t: 0, bump: null };

/* ---------- layout & HUD ---------- */
function resize() {
  dpr = Math.min(devicePixelRatio || 1, 2); W = innerWidth; H = innerHeight;
  cv.width = W * dpr; cv.height = H * dpr;
  L = computeLayout(W, H); buildBackground(bg, L, W, H, dpr);
}
function hud() {
  const d = $('dots'); d.innerHTML = '';
  for (let i = 0; i < C.MAX_SHOTS; i++) { const el = document.createElement('i'); if (S.results[i] !== undefined) el.className = S.results[i] ? 'g' : 'm'; d.appendChild(el); }
  $('goals').textContent = S.goals;
}

/* ---------- input ---------- */
cv.addEventListener('pointermove', (e) => { if (S.mode === 'aim') S.hover = [e.clientX, e.clientY]; });
cv.addEventListener('pointerdown', (e) => {
  if (S.mode !== 'aim') return;
  const x = e.clientX, y = e.clientY; S.hover = [x, y];
  if (y > L.sy - L.r0 * 1.5) return;
  shoot(cl(x, L.gx - L.gw * 0.1, L.gx + L.gw * 1.1), cl(y, L.gt - L.gh * 0.25, L.gb - 2));
});

/* ---------- game logic ---------- */
function shoot(px, py) {
  const { gx, gw, gt, gb, gh, pw } = L;
  const tx = px + (Math.random() - 0.5) * gw * 0.07, ty = py + (Math.random() - 0.5) * gh * 0.14;
  const nearPost = ((Math.abs(tx - gx) < pw * 1.4 || Math.abs(tx - gx - gw) < pw * 1.4) && ty > gt - pw && ty < gb) ||
                   (Math.abs(ty - gt) < pw * 1.4 && tx > gx && tx < gx + gw);
  const inside = tx > gx && tx < gx + gw && ty > gt && ty < gb;

  // Keeper picks a dive point; the shot is saved if the ball lies within glove reach of it
  const reach = gw * C.KEEPER_REACH;
  let P = Math.random() < C.KEEPER_READ_CHANCE
    ? [tx + (Math.random() - 0.5) * reach, ty + (Math.random() - 0.5) * reach]
    : [gx + gw * (0.08 + 0.84 * Math.random()), gt + gh * (0.1 + 0.8 * Math.random())];
  let out = 'miss';
  if (nearPost) out = 'post';
  else if (inside) out = Math.hypot(P[0] - tx, P[1] - ty) < reach ? 'save' : 'goal';
  if (out === 'save') P = [tx, ty];

  const [ix, iy] = keeper.idlePos(L);
  const a = cl(Math.atan2(P[0] - ix, -(P[1] - iy)), -1.45, 1.45), s = L.kh * 0.78;
  S.shot = { tx, ty, out, clock: 0, phase: 'fly', t2: 0, wait: 0, kx: P[0] - Math.sin(a) * s, ky: Math.min(P[1] + Math.cos(a) * s, gb - L.kh * 0.12), ka: a };
  S.mode = 'shoot'; audio.tone(150, 'sine', 0.15, 0.6, 45); audio.buzz(15);
}

function resolve() {
  const s = S.shot, { gh, gb } = L, dir = s.tx > W / 2 ? 1 : -1; let dur = 0.45;
  if (s.out === 'goal') {
    Object.assign(s, { x2: s.tx + (s.tx - W / 2) * 0.05, y2: s.ty + gh * 0.1, r2: L.r1 * 0.85 });
    S.goals++; S.results.push(1); S.popup = { text: 'گـــل!', color: '#f2c94c', t: 0 };
    S.shake = 14; S.bump = { x: s.tx, y: s.ty, amp: 26, t: 0 };
    audio.tone(330, 'sine', 0.5, 0.25, 990); audio.crowd(2.2, 0.5); audio.buzz([30, 40, 60]);
    for (let i = 0; i < 90; i++) S.parts.push({ x: W / 2, y: H * 0.45, vx: (Math.random() - 0.5) * 14, vy: -Math.random() * 14 - 2, c: ['#f2c94c', '#e74c3c', '#3498db', '#2ecc71', '#fff'][i % 5], r: Math.random() * 6, s: 3 + Math.random() * 4 });
  } else if (s.out === 'save') {
    Object.assign(s, { x2: s.tx + dir * W * 0.28, y2: gb + H * 0.1, r2: L.r1 * 1.9 }); dur = 0.55;
    S.results.push(0); S.popup = { text: 'سیو شد!', color: '#ff6b5b', t: 0 }; audio.tone(220, 'triangle', 0.25, 0.4, 120); audio.buzz(40);
  } else if (s.out === 'post') {
    Object.assign(s, { x2: s.tx + dir * W * 0.22, y2: gb + H * 0.14, r2: L.r1 * 1.7 }); dur = 0.55;
    S.results.push(0); S.popup = { text: 'تیرک!', color: '#ffb347', t: 0 }; S.shake = 8; audio.tone(900, 'square', 0.2, 0.25, 300); audio.buzz(40);
  } else {
    Object.assign(s, { x2: s.tx + (s.tx - W / 2) * 0.25, y2: s.ty - (s.ty < L.gt ? H * 0.1 : 0), r2: L.r1 * 0.6 }); dur = 0.4;
    S.results.push(0); S.popup = { text: 'اوت!', color: '#cfd8dc', t: 0 }; audio.tone(180, 'sawtooth', 0.3, 0.15, 90);
  }
  s.dur = dur; s.phase = 'after'; s.t2 = 0; hud();
}

function next() {
  S.shots++; S.shot = null; S.bump = null;
  if (S.shots >= C.MAX_SHOTS) return end();
  S.mode = 'aim';
}
function end() {
  S.mode = 'over';
  $('endTitle').textContent = S.goals === C.MAX_SHOTS ? 'تو یه اسطوره‌ای! 🏆' : S.goals >= 3 ? 'بازی خوبی بود! ⚽' : 'دروازه‌بان دیوار بود! 🧱';
  $('endScore').textContent = `${S.goals} گل از ${C.MAX_SHOTS} ضربه`;
  $('overlay').classList.add('on');
}
$('restart').onclick = () => {
  Object.assign(S, { shots: 0, goals: 0, results: [], shot: null, mode: 'aim', parts: [], popup: null });
  $('overlay').classList.remove('on'); hud();
};

/* ---------- update ---------- */
function update(dt) {
  S.t += dt; S.spin += dt * (S.mode === 'shoot' ? 18 : 0);
  if (S.shake > 0) S.shake = Math.max(0, S.shake - dt * 30);
  if (S.bump) { S.bump.t += dt; if (S.bump.t > 1.2) S.bump = null; }
  if (S.popup) S.popup.t += dt;
  S.parts.forEach((p) => { p.x += p.vx; p.y += p.vy; p.vy += 0.45; p.vx *= 0.99; });
  S.parts = S.parts.filter((p) => p.y < H + 20);
  const s = S.shot;
  if (s) {
    s.clock += dt;
    if (s.phase === 'fly' && s.clock >= C.FLIGHT_TIME) resolve();
    else if (s.phase === 'after') { s.t2 = Math.min(1, s.t2 + dt / s.dur); s.wait += dt; if (s.wait > C.RESULT_TIME) next(); }
  }
  keeper.update(dt, L, S.shot);
}

/* ---------- draw ---------- */
function ballState() {
  const { sx, sy, r0, r1 } = L, s = S.shot;
  if (!s) return { x: sx, y: sy + Math.sin(S.t * 3) * 2, r: r0, a: 1, front: true, e: 0 };
  if (s.phase === 'fly') {
    const e = eo(cl(s.clock / C.FLIGHT_TIME, 0, 1));
    return { x: lerp(sx, s.tx, e), y: lerp(sy, s.ty, e) - Math.sin(Math.PI * e) * H * 0.04, r: lerp(r0, r1, e), a: 1, front: true, e };
  }
  const e = eo(s.t2), h = s.out === 'goal' ? 0 : Math.sin(Math.PI * e) * H * 0.05;
  return { x: lerp(s.tx, s.x2, e), y: lerp(s.ty, s.y2, e) - h, r: lerp(r1, s.r2, e), a: s.out === 'miss' ? 1 - e * 0.7 : 1, front: s.out !== 'goal', e: 1 };
}
function drawBallFull(b) {
  if (!S.shot || S.shot.phase === 'fly') {
    const gy = lerp(L.sy + L.r0 * 0.95, L.gb + 4, b.e);
    ctx.fillStyle = '#0006'; ctx.beginPath(); ctx.ellipse(b.x, gy, b.r * 0.9, b.r * 0.28, 0, 0, 7); ctx.fill();
  }
  drawBall(ctx, b.x, b.y, b.r, S.spin, b.a);
}
function drawCrosshair() {
  const p = 0.5 + 0.5 * Math.sin(S.t * 4);
  if (S.hover && S.hover[1] < L.sy - L.r0 * 1.5) {
    const x = cl(S.hover[0], L.gx - L.gw * 0.1, L.gx + L.gw * 1.1), y = cl(S.hover[1], L.gt - L.gh * 0.25, L.gb - 2);
    ctx.strokeStyle = '#f2c94c'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(x, y, 16 + p * 3, 0, 7);
    ctx.moveTo(x - 24, y); ctx.lineTo(x - 8, y); ctx.moveTo(x + 8, y); ctx.lineTo(x + 24, y);
    ctx.moveTo(x, y - 24); ctx.lineTo(x, y - 8); ctx.moveTo(x, y + 8); ctx.lineTo(x, y + 24); ctx.stroke();
  }
  ctx.fillStyle = '#fff'; ctx.globalAlpha = 0.6 + 0.4 * p; ctx.font = '700 ' + Math.max(15, W * 0.04) + 'px Tahoma';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('روی نقطه دلخواه دروازه بزن', W / 2, L.sy - L.r0 * 2.6); ctx.globalAlpha = 1;
}
function drawPopup() {
  const p = S.popup, t = p.t, sc = t < 0.35 ? eo(t / 0.35) * 1.15 : 1, al = t > 1.3 ? Math.max(0, 1 - (t - 1.3) / 0.3) : 1;
  ctx.save(); ctx.translate(W / 2, H * 0.52); ctx.scale(sc, sc); ctx.globalAlpha = al;
  ctx.font = '900 ' + Math.min(W * 0.17, 90) + 'px Tahoma'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.lineWidth = 8; ctx.strokeStyle = '#000b'; ctx.lineJoin = 'round'; ctx.strokeText(p.text, 0, 0);
  ctx.shadowColor = p.color; ctx.shadowBlur = 24; ctx.fillStyle = p.color; ctx.fillText(p.text, 0, 0); ctx.restore();
}
function draw() {
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.save();
  if (S.shake > 0) ctx.translate((Math.random() - 0.5) * S.shake, (Math.random() - 0.5) * S.shake);
  ctx.drawImage(bg, 0, 0, W, H);
  drawGoalBack(ctx, L); keeper.draw(ctx, L);
  const b = ballState();
  if (!b.front) drawBallFull(b);
  drawGoalFront(ctx, L, S.bump);
  if (b.front) drawBallFull(b);
  if (S.mode === 'aim') drawCrosshair();
  S.parts.forEach((p) => { ctx.fillStyle = p.c; ctx.fillRect(p.x, p.y, p.s, p.r); });
  if (S.popup) drawPopup();
  ctx.restore();
}

/* ---------- boot ---------- */
let last = performance.now();
function loop(ts) { const dt = Math.min(0.05, (ts - last) / 1000); last = ts; update(dt); draw(); requestAnimationFrame(loop); }
addEventListener('resize', resize);
resize(); hud();
keeper.load(C.ASSET_BASE).catch((e) => console.error('Keeper assets failed to load', e)).finally(() => requestAnimationFrame(loop));
