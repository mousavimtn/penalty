let ac;
const ctxOf = () => (ac = ac || new (window.AudioContext || window.webkitAudioContext)());

export function tone(f, type, d, v, f2) {
  try {
    const a = ctxOf(); if (a.state === 'suspended') a.resume();
    const o = a.createOscillator(), g = a.createGain(), t = a.currentTime;
    o.type = type; o.frequency.setValueAtTime(f, t);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
    g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.001, t + d);
    o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + d);
  } catch (e) {}
}

export function crowd(len, v) {
  try {
    const a = ctxOf(), b = a.createBuffer(1, a.sampleRate * len, a.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const s = a.createBufferSource(), f = a.createBiquadFilter(), g = a.createGain(), t = a.currentTime;
    s.buffer = b; f.type = 'bandpass'; f.frequency.value = 900;
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v, t + 0.3); g.gain.linearRampToValueAtTime(0, t + len);
    s.connect(f); f.connect(g); g.connect(a.destination); s.start();
  } catch (e) {}
}

export const buzz = (p) => { try { navigator.vibrate && navigator.vibrate(p); } catch (e) {} };
