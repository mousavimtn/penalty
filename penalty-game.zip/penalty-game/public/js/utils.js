export const lerp = (a, b, t) => a + (b - a) * t;
export const cl = (v, a, b) => Math.max(a, Math.min(b, v));
export const eo = (t) => 1 - Math.pow(1 - t, 3);
