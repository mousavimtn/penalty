// Static scenery, goal, ball drawing
export function computeLayout(W, H) {
  const gw = Math.min(W * 0.78, H * 0.62);
  const L = {
    gw, gh: gw * 0.36, gx: (W - gw) / 2, hz: H * 0.21, gt: H * 0.31,
    pw: Math.max(5, gw * 0.02), sx: W / 2, sy: H * 0.8, r0: gw * 0.075, r1: gw * 0.034,
  };
  L.gb = L.gt + L.gh; L.kh = L.gh * 0.8;
  return L;
}

export function buildBackground(canvas, L, W, H, dpr) {
  canvas.width = W * dpr; canvas.height = H * dpr;
  const c = canvas.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
  const { hz, gb } = L;
  let g = c.createLinearGradient(0, 0, 0, hz); g.addColorStop(0, '#070b18'); g.addColorStop(1, '#1d2c4f');
  c.fillStyle = g; c.fillRect(0, 0, W, hz);
  const cols = ['#e74c3c', '#f1c40f', '#ecf0f1', '#3498db', '#2c3e50', '#e67e22', '#9b59b6'];
  const adH = H * 0.045, crowdB = hz - adH;
  for (let y = H * 0.02, row = 0; y < crowdB; y += 9, row++)
    for (let x = (row % 2) * 5; x < W; x += 10) {
      c.fillStyle = cols[(Math.random() * cols.length) | 0]; c.globalAlpha = 0.35 + 0.5 * (y / crowdB);
      c.beginPath(); c.arc(x, y, 3.2, 0, 7); c.fill();
    }
  c.globalAlpha = 1;
  [[0, 0], [W, 0]].forEach(([x, y]) => {
    const r = c.createRadialGradient(x, y, 0, x, y, W * 0.7); r.addColorStop(0, '#fff8'); r.addColorStop(1, '#fff0');
    c.fillStyle = r; c.fillRect(0, 0, W, hz);
  });
  const ads = ['#c0392b', '#2980b9', '#27ae60', '#8e44ad', '#d35400'], n = 6, aw = W / n;
  for (let i = 0; i < n; i++) {
    c.fillStyle = ads[i % 5]; c.fillRect(i * aw, crowdB, aw, adH);
    c.fillStyle = '#fff'; c.font = '800 ' + adH * 0.5 + 'px Tahoma'; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillText(i % 2 ? 'پنالتی PRO' : '⚽ GOAL', i * aw + aw / 2, crowdB + adH / 2);
  }
  const N = 14;
  for (let i = 0; i < N; i++) {
    const y0 = hz + (H - hz) * Math.pow(i / N, 1.7), y1 = hz + (H - hz) * Math.pow((i + 1) / N, 1.7);
    c.fillStyle = i % 2 ? '#2f8a3a' : '#277a31'; c.fillRect(0, y0, W, y1 - y0 + 1);
  }
  g = c.createLinearGradient(0, hz, 0, H); g.addColorStop(0, '#0008'); g.addColorStop(0.5, '#0000');
  c.fillStyle = g; c.fillRect(0, hz, W, H - hz);
  c.strokeStyle = '#ffffffd0'; c.lineWidth = 3; c.beginPath();
  c.moveTo(W * 0.02, gb); c.lineTo(W * 0.98, gb);
  c.moveTo(W * 0.06, gb); c.lineTo(-W * 0.12, H * 0.93); c.moveTo(W * 0.94, gb); c.lineTo(W * 1.12, H * 0.93);
  c.moveTo(-W * 0.12, H * 0.93); c.lineTo(W * 1.12, H * 0.93);
  c.moveTo(L.gx - L.gw * 0.1, gb); c.lineTo(L.gx - L.gw * 0.35, H * 0.62);
  c.lineTo(L.gx + L.gw * 1.35, H * 0.62); c.lineTo(L.gx + L.gw * 1.1, gb);
  c.stroke();
  c.fillStyle = '#fff'; c.beginPath(); c.ellipse(L.sx, L.sy + L.r0 * 0.9, 8, 3.5, 0, 0, 7); c.fill();
  g = c.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, H * 0.85); g.addColorStop(0, '#0000'); g.addColorStop(1, '#000a');
  c.fillStyle = g; c.fillRect(0, 0, W, H);
}

export function drawGoalBack(ctx, L) {
  const { gx, gw, gt, gb } = L, d = gw * 0.06;
  const bx0 = gx + d, bx1 = gx + gw - d, bt = gt + d * 0.6, bb = gb - d * 0.15;
  ctx.fillStyle = '#0007'; ctx.beginPath();
  ctx.moveTo(gx, gb); ctx.lineTo(gx, gt); ctx.lineTo(bx0, bt); ctx.lineTo(bx1, bt); ctx.lineTo(gx + gw, gt);
  ctx.lineTo(gx + gw, gb); ctx.lineTo(bx1, bb); ctx.lineTo(bx0, bb); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#ffffff30'; ctx.lineWidth = 1; ctx.beginPath();
  ctx.moveTo(gx, gt); ctx.lineTo(bx0, bt); ctx.moveTo(gx + gw, gt); ctx.lineTo(bx1, bt);
  ctx.moveTo(gx, gb); ctx.lineTo(bx0, bb); ctx.moveTo(gx + gw, gb); ctx.lineTo(bx1, bb);
  ctx.stroke();
}

export function drawGoalFront(ctx, L, bump) {
  const { gx, gw, gt, gb, gh, pw } = L;
  ctx.save(); ctx.beginPath(); ctx.rect(gx, gt, gw, gh); ctx.clip();
  ctx.strokeStyle = '#ffffff38'; ctx.lineWidth = 1.2;
  const sp = 16, amp = bump ? bump.amp * Math.exp(-bump.t * 3.2) * Math.cos(bump.t * 18) : 0;
  const off = (x, y) => (bump ? amp * Math.exp(-((x - bump.x) ** 2 + (y - bump.y) ** 2) / (2 * (gw * 0.2) ** 2)) : 0);
  ctx.beginPath();
  for (let y = gt; y <= gb; y += sp) for (let x = gx; x <= gx + gw; x += 10) { const yy = y + off(x, y); x === gx ? ctx.moveTo(x, yy) : ctx.lineTo(x, yy); }
  for (let x = gx; x <= gx + gw; x += sp) for (let y = gt; y <= gb; y += 10) { const o = off(x, y), xx = x + o * 0.3, yy = y + o; y === gt ? ctx.moveTo(xx, yy) : ctx.lineTo(xx, yy); }
  ctx.stroke(); ctx.restore();
  ctx.save(); ctx.shadowColor = '#0009'; ctx.shadowBlur = 10; ctx.shadowOffsetY = 4;
  ctx.strokeStyle = '#f7f7f7'; ctx.lineWidth = pw; ctx.lineCap = 'square';
  ctx.beginPath(); ctx.moveTo(gx, gb); ctx.lineTo(gx, gt); ctx.lineTo(gx + gw, gt); ctx.lineTo(gx + gw, gb); ctx.stroke();
  ctx.restore();
}

export function drawBall(ctx, x, y, r, rot, alpha) {
  ctx.save(); ctx.globalAlpha = alpha; ctx.translate(x, y);
  ctx.beginPath(); ctx.arc(0, 0, r, 0, 7); ctx.clip();
  const g = ctx.createRadialGradient(-r * 0.35, -r * 0.35, r * 0.1, 0, 0, r); g.addColorStop(0, '#fff'); g.addColorStop(1, '#bfc5cc');
  ctx.fillStyle = g; ctx.fillRect(-r, -r, 2 * r, 2 * r);
  ctx.fillStyle = '#1b1b1b'; ctx.rotate(rot);
  ctx.beginPath(); for (let i = 0; i < 5; i++) { const a = (i * Math.PI * 2) / 5; ctx.lineTo(Math.cos(a) * r * 0.32, Math.sin(a) * r * 0.32); } ctx.fill();
  for (let i = 0; i < 5; i++) { const a = (i * Math.PI * 2) / 5 + 0.63; ctx.beginPath(); ctx.arc(Math.cos(a) * r * 0.95, Math.sin(a) * r * 0.95, r * 0.3, 0, 7); ctx.fill(); }
  ctx.restore();
  ctx.save(); ctx.globalAlpha = alpha * 0.5; ctx.strokeStyle = '#000'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.stroke(); ctx.restore();
}
