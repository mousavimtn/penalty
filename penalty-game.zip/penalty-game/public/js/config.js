// Tweak gameplay here
export const CONFIG = {
  MAX_SHOTS: 5,
  FLIGHT_TIME: 0.7,          // seconds the ball takes to reach the goal
  RESULT_TIME: 1.7,          // seconds before the next shot
  KEEPER_REACH: 0.17,        // glove reach as a fraction of goal width (higher = easier saves)
  KEEPER_READ_CHANCE: 0.2,   // chance the keeper "reads" the shot and dives to the right spot
  ASSET_BASE: './assets/keeper/',
};
